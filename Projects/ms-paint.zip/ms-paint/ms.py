import tkinter as tk
from tkinter import colorchooser, simpledialog



class PaintApp:
    def __init__(self,root):
        self.root=root
        self.root.title("Ms-Paint Clone")

        self.pen_button=tk.Button(self.root,text="Pen",bg="white", command=self.use_pen)
        self.pen_button.pack(side=tk.LEFT)


        self.brush_button = tk.Button(self.root, text="Brush", bg="white", command=self.use_brush)
        self.brush_button.pack(side=tk.LEFT)


        self.color_button = tk.Button(self.root, text="Color", bg="white", command=self.choose_color)
        self.color_button.pack(side=tk.LEFT)


        self.size_button = tk.Button(self.root, text="Size", bg="white", command=self.choose_color)
        self.size_button.pack(side=tk.LEFT)

        self.canvas= tk.Canvas(self.root, bg="white", width=800, height=600)
        self.canvas.pack()

        self.canvas.bind("<B1-Motion>",self.paint)

        self.pen_color="black"
        self.pen_size=1
        self.tool="pen"
    def use_pen(self):
        self.tool="pen"
        self.pen_size=1
    def use_brush(self):
        self.tool="brush"
        self.pen_size=5
    def choose_color(self):
        color=colorchooser.askcolor(color=self.pen_color)[1]
        if color:
            self.pen_color=color
    def paint(self,event):
        x1, y1 = (event.x - self.pen_size), (event.y - self.pen_size)
        x2, y2 = (event.x + self.pen_size), (event.y + self.pen_size)
        self.canvas.create_oval(x1, y1, x2, y2, fill=self.pen_color, outline=self.pen_color)



if __name__ == "__main__":
    root = tk.Tk()
    app = PaintApp(root)
    root.mainloop()