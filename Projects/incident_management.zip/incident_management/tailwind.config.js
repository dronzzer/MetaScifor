/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './templates/incidents/**/*.html',  // Your Django templates
    './static/**/*.js',       // Any JavaScript files in your static folder
    './static/**/*.css',      // Any additional CSS in your static folder
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

