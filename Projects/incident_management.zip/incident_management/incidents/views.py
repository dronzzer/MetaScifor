from django.shortcuts import render, redirect, get_object_or_404
from .models import Incident, IncidentRequest
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.core.mail import send_mail
from django.utils import timezone
from .forms import IncidentForm  # Assuming you've created a form for Incident
import logging
from django.contrib.auth.models import User
from django.db.models import Q
from django.contrib.auth.decorators import permission_required
from django.urls import reverse
from django.contrib.auth.models import Group
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.core.exceptions import PermissionDenied
# Set up logging
logger = logging.getLogger(__name__)

# Create the Incident Manager group if not already created
incident_manager_group, created = Group.objects.get_or_create(name='Incident Manager')


@permission_required('incidents.can_approve_requests', raise_exception=True)
@login_required
def approve_requests_view(request, request_id):
    # Fetch the incident request
    incident_request = get_object_or_404(IncidentRequest, id=request_id)

    if incident_request.is_approved:
        logger.warning(f'Incident request "{incident_request.id}" is already approved.')
        return redirect('incident_list')  # Redirect if already approved

    # Update the request as approved
    incident_request.is_approved = True
    incident_request.approved_by = request.user
    incident_request.approved_at = timezone.now()
    incident_request.save()

    # Update the related incident
    incident = incident_request.incident
    incident.status = 'investigating'  # Set initial status to Investigating
    incident.assigned_to = request.user  # Assign the approving manager
    incident.save()

    logger.info(f'Incident "{incident.title}" approved by {request.user.username}')

    # Optionally send email notification
    # ...
    messages.success(request, f'Incident "{incident.title}" has been successfully approved.')

    # Redirect to the incident list after approval
    return redirect('incident_list')

@permission_required('incidents.can_approve_requests', raise_exception=True)
@login_required
def decline_requests_view(request, request_id):
    # Fetch the incident request
    incident_request = get_object_or_404(IncidentRequest, id=request_id)

    if incident_request.is_approved:
        logger.warning(f'Incident request "{incident_request.id}" has already been processed.')
        return redirect('incident_list')  # Redirect if already processed

    # Mark the request as declined
    incident_request.is_declined = True
    incident_request.declined_by = request.user
    incident_request.declined_at = timezone.now()
    incident_request.save()

    logger.info(f'Incident request "{incident_request.id}" declined by {request.user.username}')
    messages.success(request, f'Incident request "{incident_request.incident.title}" has been successfully declined.')

    # Redirect to the incident list or approval list after declining
    return redirect('approve_requests_list')





@permission_required('incidents.can_approve_requests', raise_exception=True)
@login_required
def approve_requests_list(request):
    # Filter incident requests that are not approved and refer to the associated incidents that are not declined
    incident_requests = IncidentRequest.objects.filter(is_approved=False, is_declined=False)

    paginator = Paginator(incident_requests, 10)  # Show 10 requests per page
    page_number = request.GET.get('page')

    try:
        incident_requests_page = paginator.page(page_number)
    except PageNotAnInteger:
        # If page is not an integer, deliver the first page.
        incident_requests_page = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 999), deliver the last page of results.
        incident_requests_page = paginator.page(paginator.num_pages)

    # Check if there are no requests and pass that info to the template
    no_requests = not incident_requests.exists()

    return render(request, 'incidents/approve_requests.html', {
        'incident_requests': incident_requests_page,  # Pass the paginated requests to the template
        'no_requests': no_requests,
    })


@login_required
def profile_view(request):
    # Check if the user is part of the 'Incident Manager' group
    is_incident_manager = request.user.groups.filter(name='Incident Manager').exists()
    pending_requests = IncidentRequest.objects.filter(is_approved=False) if is_incident_manager else None

    # Pass the result to the template
    return render(request, 'incidents/profile.html', {
        'user': request.user,
        'is_incident_manager': is_incident_manager,
        'pending_requests': pending_requests,
    })



class CustomLoginView(LoginView):
    template_name = 'incidents/login.html'

    def dispatch(self, request, *args, **kwargs):
        # If the user is already authenticated, redirect to the profile page
        if request.user.is_authenticated:
            return redirect('profile')  # Ensure 'profile' is the correct URL name for the profile page
        return super().dispatch(request, *args, **kwargs)

    def get_success_url(self):
        # Redirect to profile after successful login
        return reverse('profile')  # Make sure the 'profile' URL is defined in your urls.py


@permission_required('incidents.add_incident', raise_exception=True)
@login_required
def report_incident(request):
    if request.method == 'POST':
        form = IncidentForm(request.POST, request.FILES)
        if form.is_valid():
            # Create the incident without saving it yet
            incident = form.save(commit=False)
            incident.reported_by = request.user  # Assign the current user as the reporter
            incident.status = 'open'  # Set the default status to 'Open'
            incident.save()  # Save the incident

            # Create an incident request
            incident_request = IncidentRequest(
                incident=incident,
                requested_by=request.user,
                requested_at=timezone.now()
            )
            incident_request.save()  # Save the incident request

            # Automatically assign to an Incident Manager (filtered by group)
            manager = User.objects.filter(Q(groups__name='Incident Manager')).first()

            if manager:
                # Send email notification to the assigned manager
                try:
                    send_mail(
                        subject=f'New Incident Request: {incident.title}',
                        message=(
                            f'Incident request "{incident.title}" has been made by {request.user.username}.\n\n'
                            f'Incident Type: {incident.get_incident_type_display()}\n'
                            f'Severity: {incident.severity}\n'
                            f'You have been assigned to handle this incident request.'
                        ),
                        from_email='admin@cyberplatform.com',
                        recipient_list=[manager.email],
                    )
                    logger.info(f'Email sent to {manager.email} regarding incident "{incident.title}".')
                except Exception as e:
                    logger.error(f'Error sending email for incident "{incident.title}": {e}')
            else:
                logger.warning('No incident manager found to assign the request.')

            # Redirect to the success page after reporting
            return redirect('request_submitted')  # Adjust to your URL name for the success page

    else:
        form = IncidentForm()  # Create a new form instance if not a POST request

    # Render the page with the form for GET request
    return render(request, 'incidents/report_incident.html', {'form': form})

def request_submitted(request):
    return render(request, 'incidents/request_submitted.html')

@login_required
def incident_list(request):
    # Fetch only incidents where the related IncidentRequest is approved
    approved_incidents = Incident.objects.filter(incidentrequest__is_approved=True)

    return render(request, 'incidents/incident_list.html', {'incidents': approved_incidents})

@login_required
def incident_detail(request, pk):
    incident = get_object_or_404(Incident, pk=pk)

    # Check if the user has permission to view the incident
    if request.user.has_perm('incidents.view_incident'):
        return render(request, 'incidents/incident_detail.html', {'incident': incident})
    else:
        return redirect('home')


@login_required
def edit_incident(request, pk):
    incident = get_object_or_404(Incident, pk=pk)
    if request.user.groups.filter(name='Reporter').exists():
        raise PermissionDenied("You do not have permission to edit this incident.")


    if request.method == 'POST':
        form = IncidentForm(request.POST, request.FILES, instance=incident)
        if form.is_valid():
            form.save()
            return redirect('incident_detail', pk=pk)  # Redirect to the incident detail page
    else:
        form = IncidentForm(instance=incident)

    return render(request, 'incidents/edit_incident.html', {'form': form, 'incident': incident})

@login_required
def delete_incident(request, pk):
    try:
        incident = Incident.objects.get(pk=pk)
    except Incident.DoesNotExist:
        # If the incident is not found, log the error and redirect with a message
        messages.error(request, "Incident not found or already deleted.")
        return redirect('approved_incidents')  # Redirect to the list of approved incidents

    # Check if the user is a reporter
    if request.user.groups.filter(name='Reporter').exists():
        messages.error(request, "You do not have permission to delete this incident.")
        return redirect('approved_incidents')  # Redirect to the list of approved incidents

    if request.method == 'POST':
        incident.delete()
        messages.success(request, "Incident successfully deleted.")
        return redirect('approved_incidents')

    return render(request, 'incidents/delete_incident.html', {'incident': incident})
@login_required
def profile_detail(request):
    return render(request, 'incidents/profile_detail.html')
