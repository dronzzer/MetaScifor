from django.apps import AppConfig
from django.db.models.signals import post_migrate

def setup_incident_manager_permissions(sender, **kwargs):
    from django.contrib.auth.models import Group, Permission  # Import here to avoid early loading
    incident_manager_group, created = Group.objects.get_or_create(name='Incident Manager')
    permission = Permission.objects.get(codename='can_approve_requests')
    incident_manager_group.permissions.add(permission)

class IncidentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'incidents'

    def ready(self):
        post_migrate.connect(setup_incident_manager_permissions, sender=self)
