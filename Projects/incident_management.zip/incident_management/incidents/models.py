from django.db import models
from django.contrib.auth.models import User
from django.conf import settings

class Incident(models.Model):
    STATUS_CHOICES = [
        ('open', 'Open'),
        ('investigating', 'Investigating'),
        ('mitigated', 'Mitigated'),
        ('closed', 'Closed'),
    ]
    TYPE_CHOICES = [
        ('phishing', 'Phishing'),
        ('malware', 'Malware'),
        ('ddos', 'DDoS'),
        ('data_breach', 'Data Breach'),
    ]
    is_declined = models.BooleanField(default=False)
    declined_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        related_name='declined_requests',
        null=True,
        blank=True,
        on_delete=models.SET_NULL
    )
    declined_at = models.DateTimeField(null=True, blank=True)

    title = models.CharField(max_length=200)
    description = models.TextField()
    incident_type = models.CharField(max_length=50, choices=TYPE_CHOICES)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    severity = models.PositiveIntegerField(default=1)  # Severity scale from 1 to 5
    reported_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reported_incidents')
    assigned_to = models.ForeignKey(User, related_name='assigned_incidents', on_delete=models.CASCADE, null=True, blank=True)
    date_reported = models.DateTimeField(auto_now_add=True)
    last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title


class IncidentRequest(models.Model):
    STATUS_CHOICES = [
        ('open', 'Open'),
        ('investigating', 'Investigating'),
        ('mitigated', 'Mitigated'),
        ('closed', 'Closed'),
    ]
    incident = models.OneToOneField(Incident, on_delete=models.CASCADE)
    requested_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='incident_requests')
    requested_at = models.DateTimeField(auto_now_add=True)
    approved_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='approved_requests', null=True, blank=True)
    approved_at = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='open')
    is_approved = models.BooleanField(default=False)
    is_declined = models.BooleanField(default=False)

    def __str__(self):
        return f"Request for {self.incident.title} by {self.requested_by.username}"

    class Meta:
        # Adding custom permission for approving incident requests
        permissions = [
            ('can_approve_requests', 'Can approve incident requests'),
        ]
