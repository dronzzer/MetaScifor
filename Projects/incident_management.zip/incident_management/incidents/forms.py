from django import forms
from .models import Incident


class IncidentForm(forms.ModelForm):
    date_discovered = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        required=True,
        label="Date and Time of Discovery",
    )
    date_occurred = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        required=False,
        label="Date and Time Incident Occurred (if known)",
    )
    affected_systems = forms.CharField(
        required=False,
        label="Affected Systems",
        widget=forms.TextInput(attrs={'placeholder': 'e.g., Web server, Database'})
    )
    evidence = forms.FileField(
        required=False,
        label="Attach Files (optional)",
        widget=forms.ClearableFileInput(attrs={'multiple': False})
    )
    evidence_url = forms.URLField(
        required=False,
        label="Link to Additional Evidence (optional)"
    )
    priority = forms.ChoiceField(
        choices=[('critical', 'Critical'), ('high', 'High'), ('medium', 'Medium'), ('low', 'Low')],
        required=True,
        label="Urgency Level"
    )

    class Meta:
        model = Incident
        fields = ['title', 'description', 'incident_type', 'severity', 'status',
                  'date_discovered', 'date_occurred', 'affected_systems', 'evidence', 'evidence_url',
                  'priority']  # Include all relevant fields

    # Custom validation for 'title'
    def clean_title(self):
        title = self.cleaned_data.get('title')
        if not title:
            raise forms.ValidationError("Title is required.")
        return title

    # Custom validation for 'description'
    def clean_description(self):
        description = self.cleaned_data.get('description')
        if not description or len(description) < 10:
            raise forms.ValidationError("Description must be at least 10 characters long.")
        return description

    # Custom validation for 'severity'
    def clean_severity(self):
        severity = self.cleaned_data.get('severity')
        if severity < 1 or severity > 5:
            raise forms.ValidationError("Severity must be between 1 and 5.")
        return severity

    # Additional validations can be added for other fields if needed
