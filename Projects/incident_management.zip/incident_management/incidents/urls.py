from django.urls import path
from . import views
from .views import CustomLoginView
from django.contrib.auth import views as auth_views
from django.views.generic import RedirectView
from .views import approve_requests_list, approve_requests_view, decline_requests_view


urlpatterns = [
    path('', RedirectView.as_view(url='/login/', permanent=True), name='root_redirect'),  # Root redirects to login
    path('report/', views.report_incident, name='report_incident'),  # Report an incident
    path('incidents/', views.incident_list, name='incident_list'),  # List of incidents
    path('login/', CustomLoginView.as_view(), name='login'),  # Custom login view
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),  # Logout view
    path('profile/', views.profile_view, name='profile'),  # Profile page
    path('profile/details/', views.profile_detail, name='profile_detail'),  # Profile detail page
    path('approve-requests/', views.approve_requests_list, name='approve_requests_list'),  # View list of approval requests
    path('approve-requests/<int:request_id>/', approve_requests_view, name='approve_requests'),  # Approve individual request
    path('decline-requests/<int:request_id>/', decline_requests_view, name='decline_requests'),
    path('request-submitted/', views.request_submitted, name='request_submitted'),
    path('incidents/<int:pk>/', views.incident_detail, name='incident_detail'),
    path('incidents/edit/<int:pk>/', views.edit_incident, name='edit_incident'),
    path('incidents/delete/<int:pk>/', views.delete_incident, name='delete_incident'),
    path('approved-incidents/', views.incident_list, name='approved_incidents'),

]
