# importing all the required modules
from django.shortcuts import render
from yt_dlp import YoutubeDL
import os


# defining function
def youtube(request):
    # checking whether request.method is post or not
    if request.method == 'POST':
        # getting link from frontend
        link = request.POST.get('link')
        try:
            ydl_opts ={
                'format': 'best',
                'outtmpl': os.path.join(os.getcwd(), '%(title)s.%(ext)s'),
            }
            with YoutubeDL(ydl_opts) as yd1:
                yd1.download([link])

            return render(request, 'youtube/youtube.html',{'message' : 'video Downloaded Successfully' })
        except Exception as e:
            return render(request, 'youtube/youtube.html', {'error': f'An error occurred: {str(e)}'})

    return render(request, 'youtube/youtube.html')
