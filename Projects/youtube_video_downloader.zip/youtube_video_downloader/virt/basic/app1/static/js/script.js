document.addEventListener('DOMContentLoaded', function () {
    alert('JavaScript is working!');
});