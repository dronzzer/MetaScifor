from django.shortcuts import render, get_object_or_404, redirect
from .models import Post
from .forms import PostForm
from django.contrib import messages
from django.contrib.auth import login
from .forms import RegisterForm
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden

# def landing_page(request):
#     # If you have posts or any context data to pass, you can do so here
#     posts = Post.objects.all()  # Assuming you have a Post model
#     return render(request, 'app1/landing_page.html', {'posts': posts})
def home(request):
    posts = Post.objects.all()
    return render(request, 'app1/home.html', {'posts': posts})

# def home_view(request):
#     if request.user.is_authenticated:
#         return render(request, 'app1/home.html')
#     else:
#         return render(request, 'app1/landing_page.html')

@login_required
def profile(request):
    return render(request, 'app1/profile.html')

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Automatically log in the user after registration
            return redirect('home')  # Redirect to the homepage
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})

def post_detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    return render(request, 'app1/post_detail.html', {'post': post})

@login_required
def create_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            new_post = form.save(commit=False)
            new_post.author = request.user  # Set the author to the logged-in user
            new_post.save()
            messages.success(request, 'Your post has been successfully created!')
            return redirect('post_detail', pk=new_post.pk)  # Redirect to the newly created post's detail page
    else:
        form = PostForm()

    return render(request, 'app1/create_post.html', {'form': form})

@login_required
def edit_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    
    # Ensure that only the author of the post can edit it
    if post.author != request.user:
        return HttpResponseForbidden("You are not allowed to edit this post.")
    
    if request.method == 'POST':
        form = PostForm(request.POST, instance=post)  # Pass the post instance to the form
        if form.is_valid():
            form.save()
            return redirect('post_detail', pk=post.pk)
    else:
        form = PostForm(instance=post)  # Load the existing data into the form

    return render(request, 'app1/edit_post.html', {'form': form, 'post': post})

def latest_posts(request):
    # Retrieve the latest 5 posts, ordering by the publication date in descending order
    posts = Post.objects.order_by('-created_at')[:5]
    return render(request, 'app1/latest_posts.html', {'posts': posts})

def about_us(request):
    return render(request, 'app1/about_us.html')

def contact_us(request):
    return render(request, 'app1/contact_us.html')
