from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('post/<int:pk>/', views.post_detail, name='post_detail'),
    path('post/new/', views.create_post, name='create_post'),
    path('post/<int:pk>/edit/', views.edit_post, name='edit_post'),
    path('profile/', views.profile, name='profile'),
    #path('', views.landing_page, name='landing_page'),
    path('latest-posts/', views.latest_posts, name='latest_posts'),
    path('about/', views.about_us, name='about_us'),
    path('contact/', views.contact_us, name='contact')
    
]
